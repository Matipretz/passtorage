The main objective of passtorage is to generate random passwords and store them in text files without file extension. 

In the future, it will also allows to recover, overwrite, delete and backup said passwords(allready tested on CLI version).

In the beginning, a user interface was created to run on the console (aviable 'passtorage-cli' command), but currently the project has adopted tkinter as the main GUI generator.

Developed for Windows 10 and Python 3.7.2 (not tested in other versions).
Currently uses the modules: random, pyperclip and the previously mentioned tkinter.
Distributed under the MIT license.

Any intentions to port this application to another platform are welcome.

Contact: matipretz@gmail.com